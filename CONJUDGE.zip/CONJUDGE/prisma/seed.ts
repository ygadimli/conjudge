import { PrismaClient } from '@prisma/client'
import * as bcrypt from 'bcryptjs'
import 'dotenv/config'

const prisma = new PrismaClient()

async function main() {
    // Create initial user
    const hashedPassword = await bcrypt.hash('password123', 10)
    const user = await prisma.user.upsert({
        where: { email: 'raiz@conjudge.com' },
        update: {},
        create: {
            email: 'raiz@conjudge.com',
            name: 'Raiz',
            password: hashedPassword,
            rank: 'Grandmaster',
            rating: 2450,
        },
    })

    console.log({ user })

    // Create problems
    const problems = [
        {
            title: "Two Sum",
            description: "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
            difficulty: "Easy",
            tags: "Array,Hash Table",
            acceptance: "48%",
            testCases: JSON.stringify([{ input: "[2,7,11,15], 9", output: "[0,1]" }])
        },
        {
            title: "Add Two Numbers",
            description: "You are given two non-empty linked lists representing two non-negative integers.",
            difficulty: "Medium",
            tags: "Linked List,Math",
            acceptance: "39%",
            testCases: JSON.stringify([{ input: "[2,4,3], [5,6,4]", output: "[7,0,8]" }])
        },
        {
            title: "Median of Two Sorted Arrays",
            description: "Given two sorted arrays nums1 and nums2 of size m and n respectively, return the median of the two sorted arrays.",
            difficulty: "Hard",
            tags: "Array,Binary Search",
            acceptance: "35%",
            testCases: JSON.stringify([{ input: "[1,3], [2]", output: "2.0" }])
        }
    ]

    for (const p of problems) {
        await prisma.problem.create({ data: p })
    }

    // Create contests
    const contests = [
        {
            title: "Weekly Round #45",
            startTime: new Date(),
            duration: "2h 00m",
            status: "active",
            participants: 1240
        },
        {
            title: "Beginner Friendly Contest",
            startTime: new Date(Date.now() + 4 * 60 * 60 * 1000), // +4 hours
            duration: "1h 30m",
            status: "upcoming",
            participants: 850
        }
    ]

    for (const c of contests) {
        await prisma.contest.create({ data: c })
    }
}

main()
    .then(async () => {
        await prisma.$disconnect()
    })
    .catch(async (e) => {
        console.error(e)
        await prisma.$disconnect()
        process.exit(1)
    })
