"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface User {
    id: number;
    name: string;
    email: string;
    rank: string;
    rating: number;
    twoFactorEnabled: boolean;
}

interface AuthContextType {
    user: User | null;
    login: (email: string, password?: string) => Promise<void>;
    signup: (username: string, email: string, password?: string) => Promise<void>;
    logout: () => void;
    updateProfile: (name: string) => Promise<void>;
    refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null);

    const refreshUser = async () => {
        const email = localStorage.getItem("conjudge_email");
        if (email) {
            try {
                const res = await fetch(`/api/user?email=${email}`);
                if (res.ok) {
                    const userData = await res.json();
                    setUser(userData);
                } else {
                    localStorage.removeItem("conjudge_email");
                    setUser(null);
                }
            } catch (error) {
                console.error("Failed to fetch user", error);
                localStorage.removeItem("conjudge_email");
                setUser(null);
            }
        }
    };

    useEffect(() => {
        refreshUser();
    }, []);

    const login = async (email: string, password?: string) => {
        try {
            const res = await fetch("/api/auth", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "login", email, password: password || "password123" }),
            });

            if (!res.ok) throw new Error("Login failed");

            const userData = await res.json();
            setUser(userData);
            localStorage.setItem("conjudge_email", email);
        } catch (error) {
            console.error(error);
            throw error;
        }
    };

    const signup = async (username: string, email: string, password?: string) => {
        try {
            const res = await fetch("/api/auth", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "signup", email, name: username, password: password || "password123" }),
            });

            if (!res.ok) throw new Error("Signup failed");

            const userData = await res.json();
            setUser(userData);
            localStorage.setItem("conjudge_email", email);
        } catch (error) {
            console.error(error);
            throw error;
        }
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem("conjudge_email");
    };

    const updateProfile = async (name: string) => {
        if (!user) return;
        try {
            const res = await fetch("/api/user", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email: user.email, name }),
            });

            if (res.ok) {
                const updatedUser = await res.json();
                setUser(updatedUser);
            }
        } catch (error) {
            console.error("Failed to update profile", error);
        }
    };

    return (
        <AuthContext.Provider value={{ user, login, signup, logout, updateProfile, refreshUser }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
