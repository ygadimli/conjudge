interface StatCardProps {
    title: string;
    value: string;
    trend?: string;
    icon: string;
    color?: string;
}

export default function StatCard({ title, value, trend, icon, color = "var(--primary)" }: StatCardProps) {
    return (
        <div className="glass-panel" style={{ padding: "1.5rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "1rem" }}>
                <div style={{
                    width: "40px",
                    height: "40px",
                    borderRadius: "10px",
                    background: color,
                    opacity: 0.8,
                    color: "white",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "1.25rem"
                }}>
                    {icon}
                </div>
                {trend && (
                    <span style={{
                        fontSize: "0.75rem",
                        color: "#10b981",
                        background: "rgba(16, 185, 129, 0.1)",
                        padding: "0.25rem 0.5rem",
                        borderRadius: "50px"
                    }}>
                        {trend}
                    </span>
                )}
            </div>

            <div style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "0.25rem" }}>
                {value}
            </div>
            <div style={{ color: "var(--text-secondary)", fontSize: "0.875rem" }}>
                {title}
            </div>
        </div>
    );
}
