"use client";

import Link from "next/link";
import { useState } from "react";

import { useAuth } from "@/context/AuthContext";

export default function Topbar() {
    const { user, logout } = useAuth();
    const [showNotifications, setShowNotifications] = useState(false);
    const [showProfileMenu, setShowProfileMenu] = useState(false);

    return (
        <header style={{
            height: "80px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 2rem",
            marginBottom: "2rem",
            position: "relative",
            zIndex: 40
        }}>
            <div>
                <h2 style={{ fontSize: "1.5rem", fontWeight: 700 }}>Dashboard</h2>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem" }}>Welcome back, {user?.name || "Guest"}</p>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: "1.5rem" }}>
                <div style={{ position: "relative" }}>
                    <button
                        onClick={() => setShowNotifications(!showNotifications)}
                        style={{
                            background: "transparent",
                            border: "none",
                            fontSize: "1.25rem",
                            cursor: "pointer",
                            position: "relative"
                        }}
                    >
                        🔔
                        <span style={{
                            position: "absolute",
                            top: "-2px",
                            right: "-2px",
                            width: "8px",
                            height: "8px",
                            background: "var(--secondary)",
                            borderRadius: "50%"
                        }} />
                    </button>

                    {showNotifications && (
                        <div className="glass-panel" style={{
                            position: "absolute",
                            top: "100%",
                            right: 0,
                            width: "300px",
                            padding: "1rem",
                            marginTop: "0.5rem",
                            zIndex: 100
                        }}>
                            <h4 style={{ marginBottom: "1rem", fontSize: "0.875rem" }}>Notifications</h4>
                            <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
                                <div style={{ fontSize: "0.875rem", paddingBottom: "0.5rem", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                                    <span style={{ color: "var(--primary)" }}>System:</span> Welcome to ConJudge!
                                </div>
                                <div style={{ fontSize: "0.875rem", paddingBottom: "0.5rem", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                                    <span style={{ color: "#10b981" }}>Contest:</span> Weekly Round #45 is live.
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <div style={{ position: "relative" }}>
                    <div
                        style={{ display: "flex", alignItems: "center", gap: "1rem", cursor: "pointer" }}
                        onClick={() => setShowProfileMenu(!showProfileMenu)}
                    >
                        <div style={{ textAlign: "right" }}>
                            <div style={{ fontWeight: 600 }}>{user?.name || "Guest"}</div>
                            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>{user?.rank || "Visitor"}</div>
                        </div>
                        <div style={{
                            width: "40px",
                            height: "40px",
                            borderRadius: "50%",
                            background: "var(--bg-card)",
                            border: "1px solid var(--border-color)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                        }}>
                            👤
                        </div>
                    </div>

                    {showProfileMenu && (
                        <div className="glass-panel" style={{
                            position: "absolute",
                            top: "100%",
                            right: 0,
                            width: "200px",
                            padding: "0.5rem",
                            marginTop: "0.5rem",
                            zIndex: 100,
                            display: "flex",
                            flexDirection: "column",
                            gap: "0.5rem"
                        }}>
                            <Link href="/dashboard/profile" style={{ padding: "0.5rem", borderRadius: "4px", color: "white", textDecoration: "none", fontSize: "0.875rem" }} className="hover-bg">
                                My Profile
                            </Link>
                            <Link href="/dashboard/settings" style={{ padding: "0.5rem", borderRadius: "4px", color: "white", textDecoration: "none", fontSize: "0.875rem" }} className="hover-bg">
                                Settings
                            </Link>
                            <div style={{ height: "1px", background: "rgba(255,255,255,0.1)", margin: "0.25rem 0" }} />
                            <button
                                onClick={logout}
                                style={{
                                    padding: "0.5rem",
                                    borderRadius: "4px",
                                    color: "var(--primary)",
                                    fontSize: "0.875rem",
                                    background: "transparent",
                                    border: "none",
                                    textAlign: "left",
                                    cursor: "pointer",
                                    width: "100%"
                                }}
                                className="hover-bg"
                            >
                                Logout
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}
