"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const menuItems = [
    { icon: "📊", label: "Dashboard", href: "/dashboard" },
    { icon: "🧩", label: "Problems", href: "/dashboard/problems" },
    { icon: "📡", label: "Status", href: "/dashboard/status" },
    { icon: "🏅", label: "Rankings", href: "/dashboard/rankings" },
    { icon: "⚔️", label: "Battle Arena", href: "/dashboard/battle" },
    { icon: "🏆", label: "Contests", href: "/dashboard/contests" },
    { icon: "🏫", label: "School SaaS", href: "/dashboard/school" },
    { icon: "👤", label: "Profile", href: "/dashboard/profile" },
];

export default function Sidebar() {
    const pathname = usePathname();

    return (
        <aside className="glass-panel" style={{
            width: "280px",
            height: "calc(100vh - 2rem)",
            position: "fixed",
            top: "1rem",
            left: "1rem",
            display: "flex",
            flexDirection: "column",
            padding: "1.5rem",
            zIndex: 50
        }}>
            <div style={{ marginBottom: "2.5rem", display: "flex", alignItems: "center", gap: "0.75rem" }}>
                <div style={{
                    width: "40px",
                    height: "40px",
                    background: "linear-gradient(135deg, var(--primary), var(--secondary))",
                    borderRadius: "10px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "1.25rem"
                }}>
                    🚀
                </div>
                <span style={{ fontSize: "1.25rem", fontWeight: 700, letterSpacing: "-0.02em" }}>
                    ConJudge
                </span>
            </div>

            <nav style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                {menuItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            style={{
                                display: "flex",
                                alignItems: "center",
                                gap: "1rem",
                                padding: "0.75rem 1rem",
                                borderRadius: "var(--radius-sm)",
                                color: isActive ? "white" : "var(--text-secondary)",
                                background: isActive ? "rgba(99, 102, 241, 0.1)" : "transparent",
                                border: isActive ? "1px solid rgba(99, 102, 241, 0.2)" : "1px solid transparent",
                                transition: "all 0.2s ease",
                                fontWeight: isActive ? 600 : 400
                            }}
                        >
                            <span>{item.icon}</span>
                            <span>{item.label}</span>
                        </Link>
                    );
                })}
            </nav>

            <div style={{ marginTop: "auto" }}>
                <div style={{
                    padding: "1rem",
                    background: "rgba(255,255,255,0.03)",
                    borderRadius: "var(--radius-md)",
                    border: "1px solid var(--border-color)"
                }}>
                    <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)", marginBottom: "0.5rem" }}>
                        BrainType Status
                    </div>
                    <div style={{ fontWeight: 600, color: "var(--accent)" }}>Dynamic Thinker</div>
                    <div style={{
                        height: "4px",
                        background: "rgba(255,255,255,0.1)",
                        borderRadius: "2px",
                        marginTop: "0.5rem",
                        overflow: "hidden"
                    }}>
                        <div style={{ width: "75%", height: "100%", background: "var(--accent)" }} />
                    </div>
                </div>
            </div>
        </aside>
    );
}
