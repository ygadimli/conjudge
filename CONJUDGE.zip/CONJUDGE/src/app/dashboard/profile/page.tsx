"use client";

import { useAuth } from "@/context/AuthContext";
import { useState, useEffect } from "react";

export default function ProfilePage() {
    const { user, updateProfile } = useAuth();
    const [isEditing, setIsEditing] = useState(false);
    const [newName, setNewName] = useState(user?.name || "");
    const [recentSolves, setRecentSolves] = useState<{ id: number; status: string; problem: { title: string } }[]>([]);
    const [stats, setStats] = useState({ solved: 0, streak: 0 });

    useEffect(() => {
        if (user) {
            const fetchStats = async () => {
                try {
                    const res = await fetch(`/api/submissions?email=${user.email}`);
                    if (res.ok) {
                        const data = await res.json();
                        setRecentSolves(data);

                        // Calculate stats
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        const solvedCount = new Set(data.filter((s: any) => s.status === "Accepted").map((s: any) => s.problemId)).size;
                        setStats({ solved: solvedCount, streak: Math.floor(Math.random() * 10) }); // Streak is hard to calc without daily data, keeping mock for now
                    }
                } catch (error) {
                    console.error("Failed to fetch stats", error);
                }
            };
            fetchStats();
        }
    }, [user]);

    const handleSave = () => {
        updateProfile(newName);
        setIsEditing(false);
    };

    return (
        <div>
            {/* Header */}
            <div className="glass-panel" style={{ padding: "2rem", display: "flex", alignItems: "center", gap: "2rem", marginBottom: "2rem" }}>
                <div style={{
                    width: "100px",
                    height: "100px",
                    borderRadius: "50%",
                    background: "var(--bg-card)",
                    border: "2px solid var(--primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "3rem"
                }}>
                    👤
                </div>
                <div>
                    {isEditing ? (
                        <div style={{ display: "flex", gap: "0.5rem", marginBottom: "0.5rem" }}>
                            <input
                                value={newName}
                                onChange={(e) => setNewName(e.target.value)}
                                style={{
                                    background: "#000",
                                    border: "1px solid var(--border-color)",
                                    padding: "0.5rem",
                                    color: "white",
                                    borderRadius: "4px"
                                }}
                            />
                            <button onClick={handleSave} className="btn-primary" style={{ padding: "0.5rem" }}>Save</button>
                        </div>
                    ) : (
                        <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "0.5rem" }}>{user?.name || "Guest"}</h1>
                    )}
                    <div style={{ display: "flex", gap: "1rem", color: "var(--text-secondary)" }}>
                        <span>Rank: <strong style={{ color: "white" }}>{user?.rank || "Visitor"}</strong></span>
                        <span>Rating: <strong style={{ color: "var(--primary)" }}>{user?.rating || 0}</strong></span>
                        <span>Country: <strong style={{ color: "white" }}>Azerbaijan</strong></span>
                    </div>
                </div>
                <div style={{ marginLeft: "auto" }}>
                    <button
                        className="glass-panel"
                        style={{ padding: "0.75rem 1.5rem", color: "white", cursor: "pointer" }}
                        onClick={() => {
                            setNewName(user?.name || "");
                            setIsEditing(!isEditing);
                        }}
                    >
                        {isEditing ? "Cancel" : "Edit Profile"}
                    </button>
                </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "2rem" }}>
                {/* Left Column */}
                <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
                    {/* Heatmap */}
                    <div className="glass-panel" style={{ padding: "1.5rem" }}>
                        <h3 style={{ marginBottom: "1rem", fontSize: "1.25rem" }}>Activity</h3>
                        <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
                            {Array.from({ length: 365 }).map((_, i) => {
                                // Use a deterministic pseudo-random based on index
                                const seed = (i * 9301 + 49297) % 233280;
                                const val = seed / 233280;
                                const intensity = val > 0.7 ? (val > 0.85 ? 2 : 1) : 0;
                                return (
                                    <div key={i} style={{
                                        width: "12px",
                                        height: "12px",
                                        borderRadius: "2px",
                                        background: intensity === 2 ? "var(--primary)" : intensity === 1 ? "rgba(239, 68, 68, 0.4)" : "rgba(255,255,255,0.05)"
                                    }} />
                                );
                            })}
                        </div>
                    </div>

                    {/* Recent Solves */}
                    <div className="glass-panel" style={{ padding: "1.5rem" }}>
                        <h3 style={{ marginBottom: "1rem", fontSize: "1.25rem" }}>Recent Submissions</h3>
                        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                            {recentSolves.length === 0 ? (
                                <div style={{ color: "var(--text-secondary)" }}>No submissions yet.</div>
                            ) : recentSolves.map((s) => (
                                <div key={s.id} style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid rgba(255,255,255,0.05)", paddingBottom: "0.5rem" }}>
                                    <span>{s.problem.title}</span>
                                    <span style={{ color: s.status === "Accepted" ? "#10b981" : "#ef4444" }}>{s.status}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Right Column */}
                <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
                    {/* Stats */}
                    <div className="glass-panel" style={{ padding: "1.5rem" }}>
                        <h3 style={{ marginBottom: "1rem", fontSize: "1.25rem" }}>Statistics</h3>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                            <div style={{ background: "rgba(255,255,255,0.03)", padding: "1rem", borderRadius: "var(--radius-sm)" }}>
                                <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>Problems Solved</div>
                                <div style={{ fontSize: "1.5rem", fontWeight: 700 }}>{stats.solved}</div>
                            </div>
                            <div style={{ background: "rgba(255,255,255,0.03)", padding: "1rem", borderRadius: "var(--radius-sm)" }}>
                                <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>Contest Rating</div>
                                <div style={{ fontSize: "1.5rem", fontWeight: 700, color: "var(--primary)" }}>{user?.rating || 0}</div>
                            </div>
                            <div style={{ background: "rgba(255,255,255,0.03)", padding: "1rem", borderRadius: "var(--radius-sm)" }}>
                                <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>Global Rank</div>
                                <div style={{ fontSize: "1.5rem", fontWeight: 700 }}>#124</div>
                            </div>
                            <div style={{ background: "rgba(255,255,255,0.03)", padding: "1rem", borderRadius: "var(--radius-sm)" }}>
                                <div style={{ fontSize: "0.875rem", color: "var(--text-secondary)" }}>Max Streak</div>
                                <div style={{ fontSize: "1.5rem", fontWeight: 700 }}>{stats.streak} Days</div>
                            </div>
                        </div>
                    </div>

                    {/* BrainType */}
                    <div className="glass-panel" style={{ padding: "1.5rem", background: "linear-gradient(180deg, rgba(239, 68, 68, 0.1) 0%, rgba(0,0,0,0) 100%)", border: "1px solid var(--primary)" }}>
                        <h3 style={{ marginBottom: "0.5rem", fontSize: "1.25rem", color: "var(--primary)" }}>Dynamic Thinker</h3>
                        <p style={{ fontSize: "0.875rem", color: "var(--text-secondary)", marginBottom: "1rem" }}>
                            You excel at adaptive problem solving and quick pattern recognition.
                        </p>
                        <div style={{ height: "150px", background: "rgba(0,0,0,0.5)", borderRadius: "var(--radius-sm)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-muted)", fontSize: "0.75rem" }}>
                            [Radar Chart Placeholder]
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
