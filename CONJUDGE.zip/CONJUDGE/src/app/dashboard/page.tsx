import StatCard from "@/components/StatCard";

export default function DashboardPage() {
    return (
        <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
            {/* Stats Grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1.5rem" }}>
                <StatCard
                    title="Global Rating"
                    value="2,450"
                    trend="+125"
                    icon="🏆"
                    color="#f59e0b"
                />
                <StatCard
                    title="Problems Solved"
                    value="843"
                    trend="+12"
                    icon="✅"
                    color="#10b981"
                />
                <StatCard
                    title="Win Rate"
                    value="68%"
                    trend="+2.4%"
                    icon="⚔️"
                    color="#ef4444"
                />
                <StatCard
                    title="Brain Score"
                    value="92"
                    icon="🧠"
                    color="#8b5cf6"
                />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "1.5rem" }}>
                {/* Main Chart Area (Mock) */}
                <div className="glass-panel" style={{ padding: "1.5rem", minHeight: "400px" }}>
                    <h3 style={{ fontSize: "1.25rem", marginBottom: "1.5rem" }}>Performance History</h3>
                    <div style={{
                        width: "100%",
                        height: "300px",
                        background: "rgba(255,255,255,0.02)",
                        borderRadius: "var(--radius-md)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "var(--text-muted)"
                    }}>
                        [Interactive Graph Placeholder]
                    </div>
                </div>

                {/* Active Battles / Activity */}
                <div className="glass-panel" style={{ padding: "1.5rem" }}>
                    <h3 style={{ fontSize: "1.25rem", marginBottom: "1.5rem" }}>Live Battles</h3>
                    <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                        {[1, 2, 3].map((i) => (
                            <div key={i} style={{
                                padding: "1rem",
                                background: "rgba(255,255,255,0.03)",
                                borderRadius: "var(--radius-sm)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between"
                            }}>
                                <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
                                    <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#ef4444" }} />
                                    <span style={{ fontSize: "0.875rem" }}>Div 2. Arena</span>
                                </div>
                                <button style={{
                                    fontSize: "0.75rem",
                                    padding: "0.25rem 0.75rem",
                                    background: "rgba(255,255,255,0.1)",
                                    border: "none",
                                    borderRadius: "4px",
                                    color: "white",
                                    cursor: "pointer"
                                }}>
                                    Watch
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}
