"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";

interface Contest {
    id: number;
    title: string;
    startTime: string;
    duration: string;
    participants: number;
    status: string;
}

export default function ContestsPage() {
    const [activeTab, setActiveTab] = useState<"active" | "upcoming" | "past">("active");
    const [registeredContests, setRegisteredContests] = useState<number[]>([]);
    const [contests, setContests] = useState<Contest[]>([]);
    const [loading, setLoading] = useState(true);

    const { user } = useAuth();

    useEffect(() => {
        const fetchContests = async () => {
            try {
                // Pass user email to check registration status
                const url = user ? `/api/contests?email=${user.email}` : "/api/contests";
                const res = await fetch(url);
                if (res.ok) {
                    const data = await res.json();
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const formattedData = data.map((c: any) => ({
                        ...c,
                        startTime: new Date(c.startTime).toLocaleString(),
                        // If API returns isRegistered, use it, otherwise check local state (fallback)
                        isRegistered: c.isRegistered
                    }));
                    setContests(formattedData);

                    // Sync registered contests state
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const registeredIds = formattedData.filter((c: any) => c.isRegistered).map((c: any) => c.id);
                    setRegisteredContests(registeredIds);
                }
            } catch (error) {
                console.error("Failed to fetch contests", error);
            } finally {
                setLoading(false);
            }
        };
        fetchContests();
    }, [user]);

    const filteredContests = contests.filter(c => c.status === activeTab || (activeTab === "upcoming" && c.status === "upcoming") || (activeTab === "past" && c.status === "past"));

    const handleAction = async (contest: { id: number; status: string; title: string }) => {
        if (contest.status === "upcoming") {
            if (registeredContests.includes(contest.id)) {
                // Already registered
                return;
            }

            if (!user) {
                alert("Please login to register");
                return;
            }

            try {
                const res = await fetch("/api/contests", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ contestId: contest.id, email: user.email }),
                });

                if (res.ok) {
                    setRegisteredContests([...registeredContests, contest.id]);
                    // Optimistically update participant count
                    setContests(contests.map(c =>
                        c.id === contest.id ? { ...c, participants: c.participants + 1 } : c
                    ));
                    alert(`Successfully registered for ${contest.title}`);
                } else {
                    alert("Registration failed");
                }
            } catch (error) {
                console.error("Registration error", error);
                alert("An error occurred");
            }
        } else {
            alert(`Entering ${contest.title}`);
        }
    };

    return (
        <div>
            <div style={{ marginBottom: "2rem" }}>
                <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "0.5rem" }}>Contests</h1>
                <p style={{ color: "var(--text-secondary)" }}>Compete against the best and climb the leaderboard.</p>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", gap: "1rem", marginBottom: "2rem", borderBottom: "1px solid var(--border-color)" }}>
                {["active", "upcoming", "past"].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as "active" | "upcoming" | "past")}
                        style={{
                            padding: "0.75rem 1.5rem",
                            background: "transparent",
                            border: "none",
                            borderBottom: activeTab === tab ? "2px solid var(--primary)" : "2px solid transparent",
                            color: activeTab === tab ? "white" : "var(--text-secondary)",
                            cursor: "pointer",
                            fontWeight: 600,
                            textTransform: "capitalize"
                        }}
                    >
                        {tab}
                    </button>
                ))}
            </div>

            <div className="glass-panel">
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ borderBottom: "1px solid var(--border-color)", textAlign: "left" }}>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Contest Name</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Start Time</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Duration</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Participants</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={5} style={{ padding: "2rem", textAlign: "center" }}>Loading contests...</td></tr>
                        ) : filteredContests.map((contest) => {
                            const isRegistered = registeredContests.includes(contest.id);
                            return (
                                <tr key={contest.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                                    <td style={{ padding: "1rem", fontWeight: 600 }}>{contest.title}</td>
                                    <td style={{ padding: "1rem", color: contest.status === "active" ? "#10b981" : "var(--text-secondary)" }}>
                                        {contest.startTime}
                                    </td>
                                    <td style={{ padding: "1rem", color: "var(--text-secondary)" }}>{contest.duration}</td>
                                    <td style={{ padding: "1rem", color: "var(--text-secondary)" }}>{contest.participants}</td>
                                    <td style={{ padding: "1rem" }}>
                                        <button
                                            className={contest.status === "active" ? "btn-primary" : "glass-panel"}
                                            style={{
                                                padding: "0.5rem 1rem",
                                                fontSize: "0.875rem",
                                                cursor: "pointer",
                                                color: "white",
                                                border: contest.status === "active" ? "none" : "1px solid var(--border-color)",
                                                background: isRegistered ? "#10b981" : undefined
                                            }}
                                            onClick={() => handleAction(contest)}
                                        >
                                            {contest.status === "active" ? "Enter" : contest.status === "upcoming" ? (isRegistered ? "Registered" : "Register") : "View Standings"}
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
