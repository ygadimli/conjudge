"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { authenticator } from "otplib";

export default function SettingsPage() {
    const { user, updateProfile, refreshUser } = useAuth();
    const [name, setName] = useState("");
    const [is2FAEnabled, setIs2FAEnabled] = useState(false);
    const [secret, setSecret] = useState("");
    const [token, setToken] = useState("");
    const [message, setMessage] = useState("");

    useEffect(() => {
        if (user) {
            if (user.name !== name) setName(user.name);
            if (user.twoFactorEnabled !== is2FAEnabled) setIs2FAEnabled(user.twoFactorEnabled);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user]);

    const handleSaveProfile = async () => {
        await updateProfile(name);
        setMessage("Profile updated successfully!");
        setTimeout(() => setMessage(""), 3000);
    };

    const handleEnable2FA = () => {
        const newSecret = authenticator.generateSecret();
        setSecret(newSecret);
        // In a real app, we would generate a QR code here using qrcode package
        // For now, we just show the secret
    };

    const handleVerify2FA = async () => {
        const isValid = authenticator.check(token, secret);
        if (isValid) {
            // Save secret to DB via API
            try {
                const res = await fetch("/api/user", {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: user?.email, twoFactorEnabled: true, twoFactorSecret: secret }),
                });
                if (res.ok) {
                    setIs2FAEnabled(true);
                    setSecret("");
                    setToken("");
                    await refreshUser();
                    setMessage("2FA enabled successfully!");
                }
            } catch (error) {
                console.error("Failed to enable 2FA", error);
            }
        } else {
            alert("Invalid token");
        }
    };

    const handleDisable2FA = async () => {
        try {
            const res = await fetch("/api/user", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email: user?.email, twoFactorEnabled: false, twoFactorSecret: null }),
            });
            if (res.ok) {
                setIs2FAEnabled(false);
                await refreshUser();
                setMessage("2FA disabled successfully!");
            }
        } catch (error) {
            console.error("Failed to disable 2FA", error);
        }
    };

    if (!user) return <div style={{ padding: "2rem" }}>Loading...</div>;

    return (
        <div style={{ maxWidth: "800px", margin: "0 auto" }}>
            <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "2rem" }}>Settings</h1>

            {message && (
                <div style={{
                    padding: "1rem",
                    background: "rgba(16, 185, 129, 0.1)",
                    border: "1px solid #10b981",
                    color: "#10b981",
                    borderRadius: "var(--radius-sm)",
                    marginBottom: "2rem"
                }}>
                    {message}
                </div>
            )}

            <div className="glass-panel" style={{ marginBottom: "2rem" }}>
                <h2 style={{ fontSize: "1.5rem", fontWeight: 600, marginBottom: "1.5rem" }}>Profile</h2>
                <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                    <div>
                        <label style={{ display: "block", marginBottom: "0.5rem", color: "var(--text-secondary)" }}>Email</label>
                        <input
                            type="text"
                            value={user.email}
                            disabled
                            style={{
                                width: "100%",
                                padding: "0.75rem",
                                background: "rgba(255,255,255,0.05)",
                                border: "1px solid var(--border-color)",
                                borderRadius: "var(--radius-sm)",
                                color: "var(--text-muted)"
                            }}
                        />
                    </div>
                    <div>
                        <label style={{ display: "block", marginBottom: "0.5rem", color: "var(--text-secondary)" }}>Display Name</label>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            style={{
                                width: "100%",
                                padding: "0.75rem",
                                background: "var(--bg-card)",
                                border: "1px solid var(--border-color)",
                                borderRadius: "var(--radius-sm)",
                                color: "white"
                            }}
                        />
                    </div>
                    <button
                        className="btn-primary"
                        onClick={handleSaveProfile}
                        style={{ alignSelf: "flex-start", marginTop: "1rem" }}
                    >
                        Save Changes
                    </button>
                </div>
            </div>

            <div className="glass-panel">
                <h2 style={{ fontSize: "1.5rem", fontWeight: 600, marginBottom: "1.5rem" }}>Security</h2>

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
                    <div>
                        <h3 style={{ fontSize: "1.1rem", fontWeight: 500 }}>Two-Factor Authentication</h3>
                        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Add an extra layer of security to your account.</p>
                    </div>
                    {is2FAEnabled ? (
                        <button
                            onClick={handleDisable2FA}
                            style={{
                                padding: "0.5rem 1rem",
                                background: "rgba(239, 68, 68, 0.1)",
                                border: "1px solid #ef4444",
                                color: "#ef4444",
                                borderRadius: "var(--radius-sm)",
                                cursor: "pointer"
                            }}
                        >
                            Disable 2FA
                        </button>
                    ) : (
                        !secret && (
                            <button
                                className="btn-primary"
                                onClick={handleEnable2FA}
                            >
                                Enable 2FA
                            </button>
                        )
                    )}
                </div>

                {secret && !is2FAEnabled && (
                    <div style={{
                        padding: "1.5rem",
                        background: "rgba(255,255,255,0.05)",
                        borderRadius: "var(--radius-sm)",
                        marginTop: "1rem"
                    }}>
                        <p style={{ marginBottom: "1rem" }}>1. Scan this secret in your authenticator app (or enter manually):</p>
                        <code style={{
                            display: "block",
                            padding: "1rem",
                            background: "black",
                            fontFamily: "monospace",
                            marginBottom: "1.5rem",
                            wordBreak: "break-all"
                        }}>
                            {secret}
                        </code>

                        <p style={{ marginBottom: "0.5rem" }}>2. Enter the code from your app:</p>
                        <div style={{ display: "flex", gap: "1rem" }}>
                            <input
                                type="text"
                                value={token}
                                onChange={(e) => setToken(e.target.value)}
                                placeholder="000000"
                                style={{
                                    padding: "0.75rem",
                                    background: "var(--bg-card)",
                                    border: "1px solid var(--border-color)",
                                    borderRadius: "var(--radius-sm)",
                                    color: "white",
                                    width: "150px"
                                }}
                            />
                            <button
                                className="btn-primary"
                                onClick={handleVerify2FA}
                            >
                                Verify & Enable
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
