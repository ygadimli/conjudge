"use client";

import { useState, useEffect } from "react";

interface RankedUser {
    id: number;
    name: string;
    rating: number;
    rank: string;
    _count: {
        submissions: number;
    };
}

export default function RankingsPage() {
    const [users, setUsers] = useState<RankedUser[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchRankings = async () => {
            try {
                const res = await fetch("/api/user?mode=rankings");
                if (res.ok) {
                    const data = await res.json();
                    setUsers(data);
                }
            } catch (error) {
                console.error("Failed to fetch rankings", error);
            } finally {
                setLoading(false);
            }
        };

        fetchRankings();
    }, []);

    const getRankColor = (rating: number) => {
        if (rating >= 3000) return "#ff0000"; // LGM
        if (rating >= 2400) return "#ff0000"; // GM
        if (rating >= 2100) return "#ff8c00"; // Master
        if (rating >= 1900) return "#a0a"; // CM
        if (rating >= 1600) return "#00f"; // Expert
        if (rating >= 1400) return "#03a89e"; // Specialist
        return "#808080"; // Newbie
    };

    return (
        <div>
            <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "2rem" }}>Global Rankings</h1>

            <div className="glass-panel">
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ borderBottom: "1px solid var(--border-color)", textAlign: "left" }}>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)", width: "80px" }}>Rank</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>User</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Rating</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Solved</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={4} style={{ padding: "2rem", textAlign: "center" }}>Loading rankings...</td></tr>
                        ) : users.map((u, index) => (
                            <tr key={u.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                                <td style={{ padding: "1rem", fontWeight: 700, color: index < 3 ? "gold" : "var(--text-muted)" }}>
                                    #{index + 1}
                                </td>
                                <td style={{ padding: "1rem", fontWeight: 600 }}>
                                    <span style={{ color: getRankColor(u.rating) }}>{u.name}</span>
                                </td>
                                <td style={{ padding: "1rem", fontWeight: 700 }}>
                                    {u.rating}
                                </td>
                                <td style={{ padding: "1rem" }}>
                                    {u._count.submissions}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
