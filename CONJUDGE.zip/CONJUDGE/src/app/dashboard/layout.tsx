import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div style={{ minHeight: "100vh", background: "var(--bg-main)" }}>
            <Sidebar />
            <main style={{
                marginLeft: "280px",
                padding: "1rem 2rem 2rem",
                minHeight: "100vh"
            }}>
                <Topbar />
                {children}
            </main>
        </div>
    );
}
