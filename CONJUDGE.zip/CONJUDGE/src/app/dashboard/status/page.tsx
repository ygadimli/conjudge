"use client";

import { useState, useEffect } from "react";

interface Submission {
    id: number;
    status: string;
    language: string;
    createdAt: string;
    problem: {
        id: number;
        title: string;
    };
    user: {
        name: string;
    };
}

export default function StatusPage() {
    const [submissions, setSubmissions] = useState<Submission[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSubmissions = async () => {
            try {
                const res = await fetch("/api/submissions");
                if (res.ok) {
                    const data = await res.json();
                    setSubmissions(data);
                }
            } catch (error) {
                console.error("Failed to fetch submissions", error);
            } finally {
                setLoading(false);
            }
        };

        fetchSubmissions();
        // Poll every 5 seconds for real-time feel
        const interval = setInterval(fetchSubmissions, 5000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div>
            <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "2rem" }}>Real-time Status</h1>

            <div className="glass-panel">
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ borderBottom: "1px solid var(--border-color)", textAlign: "left" }}>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>ID</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>When</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>User</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Problem</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Lang</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Verdict</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading && submissions.length === 0 ? (
                            <tr><td colSpan={6} style={{ padding: "2rem", textAlign: "center" }}>Loading status...</td></tr>
                        ) : submissions.map((s) => (
                            <tr key={s.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                                <td style={{ padding: "1rem", color: "var(--text-muted)" }}>{s.id}</td>
                                <td style={{ padding: "1rem", color: "var(--text-secondary)" }}>
                                    {new Date(s.createdAt).toLocaleTimeString()}
                                </td>
                                <td style={{ padding: "1rem", fontWeight: 500, color: "var(--primary)" }}>
                                    {s.user?.name || "Unknown"}
                                </td>
                                <td style={{ padding: "1rem" }}>
                                    {s.problem.title}
                                </td>
                                <td style={{ padding: "1rem", fontFamily: "monospace", fontSize: "0.875rem" }}>
                                    {s.language}
                                </td>
                                <td style={{ padding: "1rem" }}>
                                    <span style={{
                                        color: s.status === "Accepted" ? "#10b981" :
                                            s.status === "Wrong Answer" ? "#ef4444" :
                                                s.status === "Compilation Error" ? "#f59e0b" : "white",
                                        fontWeight: 600
                                    }}>
                                        {s.status}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
