"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Problem {
    id: number;
    title: string;
    difficulty: string;
    tags: string[];
    acceptance: string;
}

export default function ProblemsPage() {
    const router = useRouter();
    const [searchQuery, setSearchQuery] = useState("");
    const [problems, setProblems] = useState<Problem[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchProblems = async () => {
            try {
                const res = await fetch("/api/problems");
                if (res.ok) {
                    const data = await res.json();
                    setProblems(data);
                }
            } catch (error) {
                console.error("Failed to fetch problems", error);
            } finally {
                setLoading(false);
            }
        };
        fetchProblems();
    }, []);

    const handleRandom = () => {
        if (problems.length > 0) {
            const randomId = problems[Math.floor(Math.random() * problems.length)].id;
            router.push(`/dashboard/problems/${randomId}`);
        }
    };

    const filteredProblems = problems.filter(p =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    );

    return (
        <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
                <h1 style={{ fontSize: "2rem", fontWeight: 700 }}>Problemset</h1>
                <div style={{ display: "flex", gap: "1rem" }}>
                    <input
                        type="text"
                        placeholder="Search problems..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        style={{
                            background: "var(--bg-card)",
                            border: "1px solid var(--border-color)",
                            padding: "0.75rem 1rem",
                            borderRadius: "var(--radius-sm)",
                            color: "white",
                            width: "300px",
                            outline: "none"
                        }}
                    />
                    <button
                        className="btn-primary"
                        style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}
                        onClick={handleRandom}
                    >
                        <span>🎲</span> Random
                    </button>
                </div>
            </div>

            <div className="glass-panel">
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ borderBottom: "1px solid var(--border-color)", textAlign: "left" }}>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>#</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Name</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Tags</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Difficulty</th>
                            <th style={{ padding: "1rem", color: "var(--text-secondary)" }}>Acceptance</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            <tr><td colSpan={5} style={{ padding: "2rem", textAlign: "center" }}>Loading problems...</td></tr>
                        ) : filteredProblems.map((p) => (
                            <tr
                                key={p.id}
                                style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", cursor: "pointer" }}
                                onClick={() => router.push(`/dashboard/problems/${p.id}`)}
                            >
                                <td style={{ padding: "1rem", color: "var(--text-muted)" }}>{p.id}</td>
                                <td style={{ padding: "1rem", fontWeight: 500 }}>
                                    {p.title}
                                </td>
                                <td style={{ padding: "1rem" }}>
                                    <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
                                        {p.tags.map(tag => (
                                            <span key={tag} style={{
                                                fontSize: "0.75rem",
                                                background: "rgba(99, 102, 241, 0.1)",
                                                color: "var(--primary)",
                                                padding: "0.25rem 0.5rem",
                                                borderRadius: "4px"
                                            }}>
                                                {tag}
                                            </span>
                                        ))}
                                    </div>
                                </td>
                                <td style={{ padding: "1rem" }}>
                                    <span style={{
                                        color: p.difficulty === "Easy" ? "#10b981" :
                                            p.difficulty === "Medium" ? "#f59e0b" :
                                                p.difficulty === "Hard" ? "#ef4444" : "#a855f7"
                                    }}>
                                        {p.difficulty}
                                    </span>
                                </td>
                                <td style={{ padding: "1rem", color: "var(--text-secondary)" }}>{p.acceptance}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
