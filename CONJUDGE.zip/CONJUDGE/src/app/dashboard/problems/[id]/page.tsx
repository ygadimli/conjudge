"use client";

import { useState, use } from "react";
import { useAuth } from "@/context/AuthContext";

export default function ProblemPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = use(params);
    const { user, refreshUser } = useAuth();
    const [code, setCode] = useState("// Write your solution here\\n#include <iostream>\\nusing namespace std;\\n\\nint main() {\\n    int a, b;\\n    cin >> a >> b;\\n    cout << a + b << endl;\\n    return 0;\\n}");

    return (
        <div style={{
            display: "grid",
            gridTemplateColumns: "350px 1fr 300px",
            height: "calc(100vh - 100px)",
            gap: "1rem"
        }}>
            {/* Problem Description */}
            <div className="glass-panel" style={{ padding: "1.5rem", overflowY: "auto" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
                    <h1 style={{ fontSize: "1.5rem", fontWeight: 700 }}>A. Simple Addition</h1>
                    <span style={{
                        fontSize: "0.75rem",
                        background: "rgba(239, 68, 68, 0.1)",
                        color: "var(--primary)",
                        padding: "0.25rem 0.5rem",
                        borderRadius: "4px"
                    }}>
                        800
                    </span>
                </div>

                <div style={{ color: "var(--text-secondary)", lineHeight: "1.6", fontSize: "0.9rem" }}>
                    <p style={{ marginBottom: "1rem" }}>
                        Given two integers <strong>a</strong> and <strong>b</strong>, print their sum.
                    </p>

                    <h3 style={{ color: "white", marginBottom: "0.5rem", fontSize: "1rem" }}>Input</h3>
                    <p style={{ marginBottom: "1rem" }}>
                        The first line contains two integers <strong>a</strong> and <strong>b</strong> (1 ≤ a, b ≤ 1000).
                    </p>

                    <h3 style={{ color: "white", marginBottom: "0.5rem", fontSize: "1rem" }}>Output</h3>
                    <p style={{ marginBottom: "1rem" }}>
                        Print a single integer — the sum of a and b.
                    </p>

                    <div style={{ marginTop: "2rem" }}>
                        <h4 style={{ fontSize: "0.875rem", marginBottom: "0.5rem" }}>Example</h4>
                        <div style={{ background: "#000", border: "1px solid var(--border-color)", borderRadius: "4px" }}>
                            <div style={{ padding: "0.5rem", borderBottom: "1px solid var(--border-color)", fontSize: "0.75rem", color: "var(--text-muted)" }}>Input</div>
                            <div style={{ padding: "0.5rem", fontFamily: "monospace" }}>3 5</div>
                            <div style={{ padding: "0.5rem", borderBottom: "1px solid var(--border-color)", borderTop: "1px solid var(--border-color)", fontSize: "0.75rem", color: "var(--text-muted)" }}>Output</div>
                            <div style={{ padding: "0.5rem", fontFamily: "monospace" }}>8</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Code Editor */}
            <div className="glass-panel" style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
                <div style={{
                    padding: "0.75rem 1rem",
                    borderBottom: "1px solid var(--border-color)",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    background: "rgba(255,255,255,0.02)"
                }}>
                    <div style={{ display: "flex", gap: "1rem" }}>
                        <span style={{ fontSize: "0.875rem", fontWeight: 600 }}>main.cpp</span>
                        <span style={{ fontSize: "0.875rem", color: "var(--text-muted)" }}>C++ 20</span>
                    </div>
                    <button style={{
                        background: "transparent",
                        border: "none",
                        color: "var(--text-secondary)",
                        cursor: "pointer",
                        fontSize: "0.875rem"
                    }}>
                        Reset
                    </button>
                </div>
                <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    style={{
                        flex: 1,
                        background: "#050505",
                        color: "#d4d4d4",
                        border: "none",
                        padding: "1rem",
                        fontFamily: "monospace",
                        fontSize: "14px",
                        resize: "none",
                        outline: "none",
                        lineHeight: "1.5"
                    }}
                    spellCheck={false}
                />
                <div style={{
                    padding: "1rem",
                    borderTop: "1px solid var(--border-color)",
                    display: "flex",
                    justifyContent: "flex-end",
                    gap: "1rem"
                }}>
                    <button style={{
                        padding: "0.5rem 1.5rem",
                        background: "transparent",
                        border: "1px solid var(--border-color)",
                        color: "white",
                        borderRadius: "var(--radius-sm)",
                        cursor: "pointer"
                    }}>
                        Run Code
                    </button>
                    <button
                        className="btn-primary"
                        onClick={async () => {
                            if (!user) {
                                alert("Please login to submit");
                                return;
                            }

                            const btn = document.activeElement as HTMLButtonElement;
                            if (btn) btn.innerText = "Submitting...";

                            try {
                                const res = await fetch("/api/submissions", {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({
                                        code,
                                        language: "cpp",
                                        problemId: id,
                                        email: user.email
                                    }),
                                });

                                if (res.ok) {
                                    const data = await res.json();
                                    if (btn) {
                                        btn.innerText = `${data.status}`;
                                        btn.style.background = data.status === "Accepted" ? "#10b981" : "#ef4444";
                                    }
                                    if (data.status === "Accepted") {
                                        // Refresh user to update rating
                                        refreshUser();
                                    }
                                } else {
                                    if (btn) btn.innerText = "Error";
                                }
                            } catch (error) {
                                console.error(error);
                                if (btn) btn.innerText = "Error";
                            }
                        }}
                    >
                        Submit
                    </button>
                </div>
            </div>

            {/* Test Cases / Output */}
            <div className="glass-panel" style={{ display: "flex", flexDirection: "column" }}>
                <div style={{
                    padding: "0.75rem 1rem",
                    borderBottom: "1px solid var(--border-color)",
                    fontWeight: 600,
                    fontSize: "0.875rem"
                }}>
                    Test Results
                </div>
                <div style={{ padding: "1rem", flex: 1, overflowY: "auto" }}>
                    <div style={{
                        padding: "1rem",
                        background: "rgba(16, 185, 129, 0.1)",
                        border: "1px solid rgba(16, 185, 129, 0.2)",
                        borderRadius: "var(--radius-sm)",
                        marginBottom: "1rem"
                    }}>
                        <div style={{ color: "#10b981", fontWeight: 600, marginBottom: "0.5rem", fontSize: "0.875rem" }}>
                            ✓ Test Case 1 Passed
                        </div>
                        <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>
                            Execution Time: 15ms
                        </div>
                    </div>

                    <div style={{
                        padding: "1rem",
                        background: "rgba(255,255,255,0.02)",
                        border: "1px solid var(--border-color)",
                        borderRadius: "var(--radius-sm)"
                    }}>
                        <div style={{ color: "var(--text-secondary)", marginBottom: "0.5rem", fontSize: "0.875rem" }}>
                            Console Output
                        </div>
                        <div style={{ fontFamily: "monospace", fontSize: "0.875rem" }}>
                            {`> Compiling...`}
                            <br />
                            {`> Running tests...`}
                            <br />
                            {`> All checks passed!`}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
