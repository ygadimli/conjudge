export default function SchoolPage() {
    return (
        <div style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            minHeight: "60vh",
            textAlign: "center"
        }}>
            <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>🏫</div>
            <h1 style={{ fontSize: "2.5rem", fontWeight: 700, marginBottom: "1rem" }}>
                School <span className="text-gradient">SaaS</span>
            </h1>
            <p style={{ color: "var(--text-secondary)", maxWidth: "500px", marginBottom: "2rem" }}>
                Create your own local Online Judge for your school or organization.
                Manage students, create contests, and analyze performance.
            </p>
            <button className="btn-primary">
                Create Organization
            </button>
        </div>
    );
}
