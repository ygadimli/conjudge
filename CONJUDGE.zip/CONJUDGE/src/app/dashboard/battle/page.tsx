"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function BattlePage() {
    const [queueStatus, setQueueStatus] = useState<"idle" | "searching" | "found">("idle");
    const [timer, setTimer] = useState(0);

    const router = useRouter();

    const startQueue = () => {
        setQueueStatus("searching");
        setTimer(0);
        const interval = setInterval(() => {
            setTimer(t => t + 1);
        }, 1000);

        // Mock match found
        setTimeout(() => {
            clearInterval(interval);
            setQueueStatus("found");
            setTimeout(() => {
                // Redirect to a random problem to simulate match start
                // In a real app, this would go to /dashboard/battle/[matchId]
                router.push("/dashboard/problems/1");
            }, 2000);
        }, 3000);
    };

    return (
        <div>
            <div style={{ textAlign: "center", marginBottom: "3rem" }}>
                <h1 style={{ fontSize: "3rem", fontWeight: 800, marginBottom: "1rem" }}>
                    Battle <span className="text-gradient">Arena</span>
                </h1>
                <p style={{ color: "var(--text-secondary)", fontSize: "1.25rem" }}>
                    Challenge opponents in real-time coding duels.
                </p>
            </div>

            {queueStatus === "found" && (
                <div style={{
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100vw",
                    height: "100vh",
                    background: "rgba(0,0,0,0.8)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 100
                }}>
                    <div className="glass-panel" style={{ padding: "3rem", textAlign: "center", border: "2px solid var(--primary)" }}>
                        <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>⚔️</div>
                        <h2 style={{ fontSize: "2rem", marginBottom: "1rem" }}>Match Found!</h2>
                        <p style={{ color: "var(--text-secondary)" }}>Connecting to server...</p>
                    </div>
                </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "2rem" }}>
                {/* Mode 1 */}
                <div className="glass-panel" style={{ padding: "2rem", textAlign: "center", position: "relative", overflow: "hidden" }}>
                    <div style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "4px",
                        background: "linear-gradient(90deg, var(--primary), var(--secondary))"
                    }} />
                    <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>⚔️</div>
                    <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>1v1 Duel</h3>
                    <p style={{ color: "var(--text-secondary)", marginBottom: "2rem" }}>
                        Ranked match against a similar skill opponent.
                    </p>
                    <button
                        className="btn-primary"
                        style={{ width: "100%" }}
                        onClick={startQueue}
                        disabled={queueStatus === "searching"}
                    >
                        {queueStatus === "searching" ? `Searching... (${timer}s)` : "Find Match"}
                    </button>
                </div>

                {/* Mode 2 */}
                <div className="glass-panel" style={{ padding: "2rem", textAlign: "center" }}>
                    <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🛡️</div>
                    <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>Team Clash</h3>
                    <p style={{ color: "var(--text-secondary)", marginBottom: "2rem" }}>
                        2v2 or 3v3 battles with shared codebase.
                    </p>
                    <button
                        className="glass-panel"
                        style={{ width: "100%", padding: "0.75rem", cursor: "pointer", color: "white" }}
                        onClick={() => alert("Team Clash queue is currently full! Try again later.")}
                    >
                        Create Party
                    </button>
                </div>

                {/* Mode 3 */}
                <div className="glass-panel" style={{ padding: "2rem", textAlign: "center" }}>
                    <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>⚡</div>
                    <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>Blitz</h3>
                    <p style={{ color: "var(--text-secondary)", marginBottom: "2rem" }}>
                        3-minute speed coding challenges.
                    </p>
                    <button
                        className="glass-panel"
                        style={{ width: "100%", padding: "0.75rem", cursor: "pointer", color: "white" }}
                        onClick={startQueue}
                    >
                        Join Queue
                    </button>
                </div>
            </div>
        </div>
    );
}
