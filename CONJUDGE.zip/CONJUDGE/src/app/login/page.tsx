"use client";

import Link from "next/link";
import { useState } from "react";

import { useAuth } from "@/context/AuthContext";

export default function LoginPage() {
    const { login } = useAuth();
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState("");

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        // Simulate API call delay
        setTimeout(() => {
            login(email);
        }, 1000);
    };

    return (
        <div style={{
            minHeight: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "var(--bg-main)",
            position: "relative",
            overflow: "hidden"
        }}>
            {/* Background Glow */}
            <div style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "800px",
                height: "800px",
                background: "radial-gradient(circle, var(--primary-glow) 0%, transparent 70%)",
                opacity: 0.3,
                zIndex: 0
            }} />

            <div className="glass-panel" style={{
                width: "100%",
                maxWidth: "400px",
                padding: "2rem",
                zIndex: 1,
                background: "rgba(17, 17, 17, 0.9)"
            }}>
                <div style={{ textAlign: "center", marginBottom: "2rem" }}>
                    <h1 style={{ fontSize: "2rem", fontWeight: 700, marginBottom: "0.5rem" }}>
                        Welcome <span className="text-gradient">Back</span>
                    </h1>
                    <p style={{ color: "var(--text-secondary)" }}>Enter your credentials to access the arena.</p>
                </div>

                <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                    <div>
                        <label style={{ display: "block", marginBottom: "0.5rem", fontSize: "0.875rem", color: "var(--text-secondary)" }}>Email</label>
                        <input
                            type="email"
                            required
                            style={{
                                width: "100%",
                                padding: "0.75rem",
                                background: "#000",
                                border: "1px solid var(--border-color)",
                                borderRadius: "var(--radius-sm)",
                                color: "white",
                                outline: "none"
                            }}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="user@example.com"
                        />
                    </div>

                    <div>
                        <label style={{ display: "block", marginBottom: "0.5rem", fontSize: "0.875rem", color: "var(--text-secondary)" }}>Password</label>
                        <input
                            type="password"
                            required
                            style={{
                                width: "100%",
                                padding: "0.75rem",
                                background: "#000",
                                border: "1px solid var(--border-color)",
                                borderRadius: "var(--radius-sm)",
                                color: "white",
                                outline: "none"
                            }}
                            placeholder="••••••••"
                        />
                    </div>

                    <button
                        type="submit"
                        className="btn-primary"
                        disabled={loading}
                        style={{ width: "100%", opacity: loading ? 0.7 : 1 }}
                    >
                        {loading ? "Authenticating..." : "Sign In"}
                    </button>
                </form>

                <div style={{ marginTop: "1.5rem", textAlign: "center", fontSize: "0.875rem", color: "var(--text-secondary)" }}>
                    Don&apos;t have an account? <Link href="/signup" style={{ color: "var(--primary)", fontWeight: 600 }}>Sign Up</Link>
                </div>
            </div>
        </div>
    );
}
