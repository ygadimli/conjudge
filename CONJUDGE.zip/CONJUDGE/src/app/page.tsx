"use client";

import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Home() {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user) {
      router.push("/dashboard");
    }
  }, [user, router]);

  return (
    <main style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Hero Section */}
      <section style={{
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        overflow: "hidden"
      }}>
        {/* Background Glow */}
        <div style={{
          position: "absolute",
          top: "20%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "600px",
          height: "600px",
          background: "radial-gradient(circle, var(--primary-glow) 0%, transparent 70%)",
          opacity: 0.5,
          zIndex: -1
        }} />

        <div className="container" style={{ textAlign: "center", position: "relative", zIndex: 1 }}>
          <div style={{
            display: "inline-block",
            padding: "0.5rem 1rem",
            borderRadius: "50px",
            background: "rgba(99, 102, 241, 0.1)",
            border: "1px solid rgba(99, 102, 241, 0.2)",
            marginBottom: "1.5rem",
            fontSize: "0.875rem",
            color: "var(--primary)"
          }}>
            🚀 The Future of Competitive Programming
          </div>

          <h1 style={{
            fontSize: "clamp(3rem, 6vw, 5rem)",
            fontWeight: 800,
            lineHeight: 1.1,
            marginBottom: "1.5rem",
            letterSpacing: "-0.02em"
          }}>
            Code. Compete. <br />
            <span className="text-gradient">Conquer.</span>
          </h1>

          <p style={{
            fontSize: "1.25rem",
            color: "var(--text-secondary)",
            maxWidth: "600px",
            margin: "0 auto 2.5rem"
          }}>
            ConJudge is the world&apos;s first AI-powered coding esports arena.
            Real-time battles, brain profile analysis, and next-gen education.
          </p>

          <Link href="/signup" className="btn-primary">
            Start Coding Now
          </Link>
        </div>
      </section>

      {/* Features Grid */}
      <section style={{ padding: "5rem 0" }}>
        <div className="container">
          <h2 className="section-title">Why ConJudge?</h2>
          <p className="section-subtitle">Beyond standard online judges. A complete ecosystem.</p>

          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: "2rem"
          }}>
            {/* Feature 1 */}
            <div className="glass-panel" style={{ padding: "2rem" }}>
              <div style={{ fontSize: "2rem", marginBottom: "1rem" }}>🧠</div>
              <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>BrainType Analysis</h3>
              <p style={{ color: "var(--text-secondary)" }}>
                AI analyzes your thinking style, not just your rating. Discover your strengths and weaknesses.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="glass-panel" style={{ padding: "2rem" }}>
              <div style={{ fontSize: "2rem", marginBottom: "1rem" }}>⚔️</div>
              <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>Esports Battles</h3>
              <p style={{ color: "var(--text-secondary)" }}>
                1v1 Duels, Team Clashes, and 5v5 Leagues with HP systems and live spectating.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="glass-panel" style={{ padding: "2rem" }}>
              <div style={{ fontSize: "2rem", marginBottom: "1rem" }}>🤖</div>
              <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>AI Problem Studio</h3>
              <p style={{ color: "var(--text-secondary)" }}>
                Infinite problem generation with dynamic difficulty adjustments based on live solves.
              </p>
            </div>
            {/* Feature 4 */}
            <div className="glass-panel" style={{ padding: "2rem" }}>
              <div style={{ fontSize: "2rem", marginBottom: "1rem" }}>🏫</div>
              <h3 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>School SaaS</h3>
              <p style={{ color: "var(--text-secondary)" }}>
                Create your own local Online Judge for your school or village with custom branding.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main >
  );
}
