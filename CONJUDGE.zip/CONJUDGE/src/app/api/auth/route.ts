import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import * as bcrypt from 'bcryptjs';

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const { action, email, password, name } = body;

        if (action === 'signup') {
            const existingUser = await prisma.user.findUnique({ where: { email } });
            if (existingUser) {
                return NextResponse.json({ error: 'User already exists' }, { status: 400 });
            }

            const hashedPassword = await bcrypt.hash(password, 10);
            const user = await prisma.user.create({
                data: {
                    email,
                    password: hashedPassword,
                    name: name || email.split('@')[0],
                },
            });

            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const { password: _p, twoFactorSecret: _t, ...userWithoutSensitive } = user;
            return NextResponse.json(userWithoutSensitive);
        }

        if (action === 'login') {
            const user = await prisma.user.findUnique({ where: { email } });
            if (!user) {
                return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
            }

            const isValid = await bcrypt.compare(password, user.password);
            if (!isValid) {
                return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
            }

            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const { password: _p, twoFactorSecret: _t, ...userWithoutSensitive } = user;
            return NextResponse.json(userWithoutSensitive);
        }

        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    } catch (error) {
        console.error('Auth error:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
