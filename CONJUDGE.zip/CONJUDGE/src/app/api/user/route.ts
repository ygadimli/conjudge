import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const mode = searchParams.get('mode');

    if (mode === 'rankings') {
        const users = await prisma.user.findMany({
            orderBy: { rating: 'desc' },
            take: 50,
            select: {
                id: true,
                name: true,
                rating: true,
                rank: true,
                _count: {
                    select: { submissions: { where: { status: 'Accepted' } } }
                }
            }
        });
        return NextResponse.json(users);
    }

    if (!email) return NextResponse.json({ error: 'Email required' }, { status: 400 });

    try {
        const user = await prisma.user.findUnique({
            where: { email },
        });

        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password: _p, twoFactorSecret: _t, ...userWithoutSensitive } = user;
        return NextResponse.json(userWithoutSensitive);
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}

export async function PUT(request: Request) {
    try {
        const body = await request.json();
        const { email, name, twoFactorEnabled, twoFactorSecret } = body;

        if (!email) {
            return NextResponse.json({ error: 'Email required' }, { status: 400 });
        }

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const updateData: any = {};
        if (name !== undefined) updateData.name = name;
        if (twoFactorEnabled !== undefined) updateData.twoFactorEnabled = twoFactorEnabled;
        if (twoFactorSecret !== undefined) updateData.twoFactorSecret = twoFactorSecret;

        const user = await prisma.user.update({
            where: { email },
            data: updateData,
        });

        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { password: _p, twoFactorSecret: _t, ...userWithoutSensitive } = user;
        return NextResponse.json(userWithoutSensitive);
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
