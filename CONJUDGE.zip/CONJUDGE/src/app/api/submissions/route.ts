import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
    try {
        const { code, language, problemId, email } = await request.json();

        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

        // Simple deterministic judge logic
        // If code contains "cout << a + b" or "print(a + b)" or similar, accept it
        const isCorrect = code.includes("a + b") || code.includes("a+b");
        const randomVerdict = isCorrect ? "Accepted" : "Wrong Answer";

        const submission = await prisma.submission.create({
            data: {
                code,
                language,
                status: randomVerdict,
                userId: user.id,
                problemId: Number(problemId)
            }
        });

        // Update user rating if Accepted (simple mock logic)
        if (randomVerdict === "Accepted") {
            await prisma.user.update({
                where: { id: user.id },
                data: { rating: { increment: 10 } }
            });
        }

        return NextResponse.json(submission);
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}

export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const email = searchParams.get('email');

        if (email) {
            const user = await prisma.user.findUnique({ where: { email } });
            if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

            const submissions = await prisma.submission.findMany({
                where: { userId: user.id },
                orderBy: { createdAt: 'desc' },
                include: { problem: true },
                take: 10
            });
            return NextResponse.json(submissions);
        } else {
            // Fetch global submissions
            const submissions = await prisma.submission.findMany({
                orderBy: { createdAt: 'desc' },
                include: {
                    problem: true,
                    user: {
                        select: { name: true }
                    }
                },
                take: 50
            });
            return NextResponse.json(submissions);
        }
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
