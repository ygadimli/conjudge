import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const email = searchParams.get('email');

        const contests = await prisma.contest.findMany({
            include: {
                registrations: true
            }
        });

        // If email is provided, check if user is registered
        let formattedContests = contests;
        if (email) {
            const user = await prisma.user.findUnique({ where: { email } });
            if (user) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                formattedContests = contests.map((c: any) => ({
                    ...c,
                    isRegistered: c.registrations.some((r: any) => r.userId === user.id)
                }));
            }
        }

        return NextResponse.json(formattedContests);
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}

export async function POST(request: Request) {
    try {
        const { contestId, email } = await request.json();

        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

        // Check if already registered
        const existing = await prisma.contestParticipant.findUnique({
            where: {
                userId_contestId: {
                    userId: user.id,
                    contestId: contestId
                }
            }
        });

        if (existing) {
            return NextResponse.json({ success: true, message: 'Already registered' });
        }

        // Register
        await prisma.$transaction([
            prisma.contestParticipant.create({
                data: {
                    userId: user.id,
                    contestId: contestId
                }
            }),
            prisma.contest.update({
                where: { id: contestId },
                data: { participants: { increment: 1 } }
            })
        ]);

        return NextResponse.json({ success: true });
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
