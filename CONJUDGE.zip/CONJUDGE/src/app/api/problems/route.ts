import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
    try {
        const problems = await prisma.problem.findMany();
        // Parse tags and testCases if needed, but for now sending as is or parsing on client
        // Actually, tags are string "Tag1,Tag2", client expects array.

        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const formattedProblems = problems.map((p: any) => ({
            ...p,
            tags: p.tags.split(','),
            testCases: JSON.parse(p.testCases)
        }));

        return NextResponse.json(formattedProblems);
    } catch {
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
